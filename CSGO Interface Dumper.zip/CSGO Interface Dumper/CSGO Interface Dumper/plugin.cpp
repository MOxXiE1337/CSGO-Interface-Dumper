#include "plugin.h"

enum
{
    DUMP_MENU,
    DUMP_WITH_JSON_MENU
};

static bool cbTestCommand(int argc, char* argv[])
{
    dputs("Test command!");
    char line[GUI_MAX_LINE_SIZE] = "";
    if (!GuiGetLineWindow("test", line))
        dputs("Cancel pressed!");
    else
        dprintf("Line: \"%s\"\n", line);
    return true;
}

PLUG_EXPORT void CBMENUENTRY(CBTYPE cbType, PLUG_CB_MENUENTRY* info)
{
    switch (info->hEntry)
    {
    case DUMP_MENU:
        dump();
        break;
    case DUMP_WITH_JSON_MENU:
        dump_with_json();
        break;
    default:
        break;
    }
}

//Initialize your plugin data here.
bool pluginInit(PLUG_INITSTRUCT* initStruct)
{
    return true; //Return false to cancel loading the plugin.
}

//Deinitialize your plugin data here.
void pluginStop()
{
}

//Do GUI/Menu related things here.
void pluginSetup()
{
    _plugin_menuaddentry(hMenu, DUMP_MENU, "Dump");
    _plugin_menuaddentry(hMenu, DUMP_WITH_JSON_MENU, "Dump with json");
}
