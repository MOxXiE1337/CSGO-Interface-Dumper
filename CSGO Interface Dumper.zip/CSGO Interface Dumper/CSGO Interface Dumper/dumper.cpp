#include <map>
#include <string>

#include "plugin.h"

#include "json/json.h"

class InterfaceReg
{
private:
    using InstantiateInterfaceFn = void* (*)();
public:
    InstantiateInterfaceFn m_CreateFn;
    const char* m_pName;
    InterfaceReg* m_pNext;
};

void dump()
{
    if (!DbgIsDebugging())
    {
        dputs("You need to be debugging to use this option!");
        return;
    }

    BridgeList<Script::Module::ModuleInfo> modules;
    if (!Script::Module::GetList(&modules))
    {
        dputs("Failed to get module list...");
        return;
    }

    for (int i = 0; i < modules.Count(); i++)
    {
        Script::Module::ModuleInfo& moduleInfo = modules[i];
        const DBGFUNCTIONS* dbgFunctions = DbgFunctions();

        std::string moduleName = moduleInfo.name;
        moduleName = moduleName.substr(0, moduleName.find('.'));
    
        duint pCreateInterface = 0;
        dbgFunctions->ValFromString((moduleName + ".CreateInterface").c_str(), &pCreateInterface);

        if (pCreateInterface == 0)
            continue;

        duint pJumpStart = pCreateInterface + 4;
        duint uJumpOffset = 0;
    
        DbgMemRead(pJumpStart + 1, &uJumpOffset, sizeof(duint));

        duint pJumpTarget = pJumpStart + uJumpOffset + 5;
          
        InterfaceReg* pRegList = nullptr;

        DbgMemRead(pJumpTarget + 6, &pRegList, sizeof(InterfaceReg*));
        DbgMemRead((duint)pRegList, &pRegList, sizeof(InterfaceReg*));

        for (InterfaceReg* pCurrentReg = pRegList; pCurrentReg != nullptr;)
        {
            InterfaceReg reg = { 0 };
            char interfaceName[MAX_STRING_SIZE] = { 0 };
            std::string strInterfaceName;

            DbgMemRead((duint)pCurrentReg, &reg, sizeof(InterfaceReg));

            DbgGetStringAt((duint)reg.m_pName, interfaceName);
            
            strInterfaceName = interfaceName;
            strInterfaceName = strInterfaceName.substr(1);
            strInterfaceName.pop_back();
            
            if (strInterfaceName == "ServerGameTags001")
            {
                pCurrentReg = reg.m_pNext;
                continue;
            }

            duint pInterface = 0;
            DbgMemRead((duint)reg.m_CreateFn + 1, &pInterface, sizeof(duint));

            std::string fullInterfaceName = moduleName + "." + strInterfaceName;

            _plugin_logprintf("%s: %p(%X)\n", fullInterfaceName.c_str(), pInterface, pInterface - moduleInfo.base);

            pCurrentReg = reg.m_pNext;
        }
    }
}

void dump_with_json()
{
    if (!DbgIsDebugging())
    {
        dputs("You need to be debugging to use this option!");
        return;
    }

    char moduleJson[GUI_MAX_LINE_SIZE] = { 0 };
    char addressJson[GUI_MAX_LINE_SIZE] = { 0 };

    if (!GuiGetLineWindow("Input module json", moduleJson))
    {
        dputs("Dumping cancled");
        return;
    }
    if (!GuiGetLineWindow("Input address json", addressJson))
    {
        dputs("Dumping cancled");
        return;
    }

    Json::Reader moduleReader;
    Json::Value moduleRoot;
    Json::Reader addressReader;
    Json::Value addressRoot;

    if (!moduleReader.parse(moduleJson, moduleRoot, false))
    {
        dputs("Failed to parse module json!");
        return;
    }
    if (!addressReader.parse(addressJson, addressRoot, false))
    {
        dputs("Failed to parse address json!");
        return;
    }
    
    std::map<std::string, duint> moduleBases;

    Json::Value::Members moduleMembers = moduleRoot.getMemberNames();
    for (auto& i : moduleMembers)
    {
        moduleBases[i] = moduleRoot[i].asUInt();
    }

    BridgeList<Script::Module::ModuleInfo> modules;
    if (!Script::Module::GetList(&modules))
    {
        dputs("Failed to get module list...");
        return;
    }

    std::map<std::string, std::vector<std::pair<std::string, duint>>> interfaceMap;

    for (int i = 0; i < modules.Count(); i++)
    {
        Script::Module::ModuleInfo& moduleInfo = modules[i];
        const DBGFUNCTIONS* dbgFunctions = DbgFunctions();

        std::string moduleName = moduleInfo.name;
        moduleName = moduleName.substr(0, moduleName.find('.'));

        duint pCreateInterface = 0;
        dbgFunctions->ValFromString((moduleName + ".CreateInterface").c_str(), &pCreateInterface);

        if (pCreateInterface == 0)
            continue;

        duint pJumpStart = pCreateInterface + 4;
        duint uJumpOffset = 0;

        DbgMemRead(pJumpStart + 1, &uJumpOffset, sizeof(duint));

        duint pJumpTarget = pJumpStart + uJumpOffset + 5;

        InterfaceReg* pRegList = nullptr;

        DbgMemRead(pJumpTarget + 6, &pRegList, sizeof(InterfaceReg*));
        DbgMemRead((duint)pRegList, &pRegList, sizeof(InterfaceReg*));

        for (InterfaceReg* pCurrentReg = pRegList; pCurrentReg != nullptr;)
        {
            InterfaceReg reg = { 0 };
            char interfaceName[MAX_STRING_SIZE] = { 0 };
            std::string strInterfaceName;

            DbgMemRead((duint)pCurrentReg, &reg, sizeof(InterfaceReg));

            DbgGetStringAt((duint)reg.m_pName, interfaceName);

            strInterfaceName = interfaceName;
            strInterfaceName = strInterfaceName.substr(1);
            strInterfaceName.pop_back();

            if (strInterfaceName == "ServerGameTags001")
            {
                pCurrentReg = reg.m_pNext;
                continue;
            }

            duint pInterface = 0;
            DbgMemRead((duint)reg.m_CreateFn + 1, &pInterface, sizeof(duint));

            if (interfaceMap.count(moduleName) == 0)
                interfaceMap[moduleName] = {};

            interfaceMap[moduleName].push_back({ moduleName + "." + strInterfaceName,pInterface - moduleInfo.base});

            pCurrentReg = reg.m_pNext;
        }
    }


    for (int i = 0; i < addressRoot.size(); i++)
    {
        std::string name = addressRoot[i].get("name", "UNKOWN").asString();
        duint address = addressRoot[i].get("address", 0).asUInt();

        if (moduleBases.count(name) == 0)
        {
            _plugin_logprintf("uint32_t %p = \"UNKOWN\";\n", address);
            continue;
        }

        duint oldImagebase = moduleBases[name];
        duint rva = address - oldImagebase;

        std::vector<std::pair<std::string, duint>>& interfaces = interfaceMap[name];

        bool found = false;
        for (auto& j : interfaces)
        {
            if (j.second == rva)
            {
                _plugin_logprintf("uint32_t %p = \"%s\";\n", address, j.first);
                found = true;
                break;
            }
        }

        if (!found)
            _plugin_logprintf("uint32_t %p = \"UNKOWN\";\n", address);
    }
 }